@extends('layouts.admin')

@section('title', 'Daftar Transaksi')

@section('content')
<div class="py-4 sm:py-6 bg-gray-50 min-h-screen">
    <div class="max-w-7xl mx-auto px-3 sm:px-4 lg:px-8">
        <!-- Header Section -->
        <div class="flex flex-col gap-3 sm:gap-4 mb-6">
            <h1 class="text-xl sm:text-2xl font-bold text-gray-900">Daftar Transaksi</h1>
            <a href="{{ route('admin.transactions.create') }}" 
               class="w-full sm:w-auto inline-flex items-center justify-center px-3 sm:px-4 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition duration-150 shadow-sm text-sm sm:text-base">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 sm:h-5 sm:w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd" />
                </svg>
                Buat Transaksi Baru
            </a>
        </div>

        <!-- Notification Section -->
        @if (session('error'))
            <div class="mb-4 p-3 sm:p-4 bg-red-50 border-l-4 border-red-400 rounded-lg shadow-sm">
                <div class="flex gap-3">
                    <div class="flex-shrink-0">
                        <svg class="h-4 w-4 sm:h-5 sm:w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div>
                        <p class="text-xs sm:text-sm text-red-700">{{ session('error') }}</p>
                    </div>
                </div>
            </div>
        @endif

        @if (session('success'))
            <div class="mb-4 p-3 sm:p-4 bg-green-50 border-l-4 border-green-400 rounded-lg shadow-sm">
                <div class="flex gap-3">
                    <div class="flex-shrink-0">
                        <svg class="h-4 w-4 sm:h-5 sm:w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div>
                        <p class="text-xs sm:text-sm text-green-700">{{ session('success') }}</p>
                    </div>
                </div>
            </div>
        @endif

        <!-- Main Card -->
        <div class="bg-white rounded-xl shadow-md overflow-hidden">
            <!-- Filter Section -->
            <div class="p-3 sm:p-4 lg:p-5 bg-white border-b border-gray-200">
                <div class="flex items-center mb-3 sm:mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 sm:h-5 sm:w-5 text-gray-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M3 3a1 1 0 011-1h12a1 1 0 011 1v3a1 1 0 01-.293.707L12 11.414V15a1 1 0 01-.293.707l-2 2A1 1 0 018 17v-5.586L3.293 6.707A1 1 0 013 6V3z" clip-rule="evenodd" />
                    </svg>
                    <h2 class="text-base sm:text-lg font-medium text-gray-700">Filter Transaksi</h2>
                </div>
                <form action="" method="GET" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3 lg:gap-4">
                    @include('admin.transactions.partials.filter')
                </form>
            </div>

            <!-- Form for Export -->
            <form action="{{ route('transactions.export') }}" method="POST" class="flex flex-col">
                
                <!-- Desktop View Table -->
                <div class="hidden lg:block overflow-x-auto flex-1">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-3 sm:px-4 py-3">
                                    <div class="flex items-center">
                                        <input type="checkbox" id="select-all"
                                            class="h-4 w-4 text-pink-500 focus:ring-pink-400 border-gray-300 rounded cursor-pointer">
                                        <label for="select-all"
                                            class="ml-2 text-xs font-medium text-gray-500 cursor-pointer">Semua</label>
                                    </div>
                                </th>
                                <th scope="col" class="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    No Invoice
                                </th>
                                <th scope="col" class="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Pelanggan
                                </th>
                                <th scope="col" class="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Total
                                </th>
                                <th scope="col" class="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Voucher
                                </th>
                                <th scope="col" class="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Point
                                </th>
                                <th scope="col" class="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Status
                                </th>
                                <th scope="col" class="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Tanggal
                                </th>
                                <th scope="col" class="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Aksi
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            @forelse($transactions as $transaction)
                                <tr class="hover:bg-gray-50 transition duration-150">
                                    <td class="px-3 sm:px-4 py-4 whitespace-nowrap">
                                        <input type="checkbox" name="selected_transactions[]"
                                            value="{{ $transaction->id }}"
                                            class="transaction-checkbox h-4 w-4 text-pink-500 focus:ring-pink-400 border-gray-300 rounded cursor-pointer">
                                    </td>
                                    <td class="px-3 sm:px-6 py-4 whitespace-nowrap text-xs sm:text-sm font-medium text-gray-900">
                                        <span class="font-mono">{{ $transaction->invoice_number }}</span>
                                    </td>
                                    <td class="px-3 sm:px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center gap-2 sm:gap-3">
                                            <div class="flex-shrink-0 h-7 w-7 sm:h-8 sm:w-8 bg-pink-100 rounded-full flex items-center justify-center text-xs sm:text-sm text-pink-500 font-medium">
                                                {{ substr($transaction->user->name ?? 'N/A', 0, 1) }}
                                            </div>
                                            <div class="min-w-0">
                                                <div class="text-xs sm:text-sm font-medium text-gray-900 truncate">
                                                    {{ $transaction->user->name ?? 'N/A' }}
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-3 sm:px-6 py-4 whitespace-nowrap text-xs sm:text-sm font-medium text-gray-900">
                                        Rp {{ number_format($transaction->total_amount, 0, ',', '.') }}
                                    </td>
                                    <td class="px-3 sm:px-6 py-4 whitespace-nowrap">
                                        @if($transaction->userVoucher?->type)
                                            <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-indigo-100 text-indigo-800">
                                                {{ ucfirst(str_replace('_', ' ', $transaction->userVoucher?->type)) }}
                                            </span>
                                        @else
                                            <span class="text-xs sm:text-sm text-gray-500">-</span>
                                        @endif
                                    </td>
                                    <td class="px-3 sm:px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center gap-1">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 sm:h-4 sm:w-4 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                            </svg>
                                            <span class="text-xs sm:text-sm text-gray-900">{{ $transaction->points_earned }}</span>
                                        </div>
                                    </td>
                                    <td class="px-3 sm:px-6 py-4 whitespace-nowrap">
                                        <span
                                            class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        {{ $transaction->payment_status == 'completed'
                                            ? 'bg-green-100 text-green-800'
                                            : ($transaction->payment_status == 'pending'
                                                ? 'bg-yellow-100 text-yellow-800'
                                                : 'bg-red-100 text-red-800') }}">
                                            {{ ucfirst($transaction->payment_status) }}
                                        </span>
                                    </td>
                                    <td class="px-3 sm:px-6 py-4 whitespace-nowrap text-xs sm:text-sm text-gray-500">
                                        <div class="flex flex-col">
                                            <span>{{ $transaction->created_at->format('d M Y') }}</span>
                                            <span class="text-xs text-gray-400">{{ $transaction->created_at->format('H:i') }}</span>
                                        </div>
                                    </td>
                                    <td class="px-3 sm:px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <a href="{{ route('admin.transactions.show', $transaction->id) }}"
                                            class="text-[#FF8FA4] hover:text-[#F542C8] transition duration-150 inline-flex items-center text-xs sm:text-sm">
                                            <span>Detail</span>
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 sm:h-4 sm:w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                                                <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                                            </svg>
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="9" class="px-3 sm:px-6 py-8 sm:py-10 text-center">
                                        <div class="flex flex-col items-center justify-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 sm:h-10 sm:w-10 text-gray-400 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                            </svg>
                                            <span class="text-sm sm:text-lg text-gray-500">Tidak ada data transaksi</span>
                                        </div>
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <!-- Tablet & Mobile View -->
                <div class="lg:hidden flex-1">
                    <div class="py-2 px-3 sm:px-4 border-b border-gray-200">
                        <div class="flex items-center space-x-2">
                            <input type="checkbox" id="select-all-mobile"
                                class="h-4 w-4 text-pink-500 focus:ring-pink-400 border-gray-300 rounded cursor-pointer">
                            <label for="select-all-mobile" class="text-xs sm:text-sm font-medium text-gray-700 cursor-pointer">Pilih Semua</label>
                        </div>
                    </div>

                    <div class="divide-y divide-gray-200">
                        @forelse($transactions as $transaction)
                            <div class="p-3 sm:p-4">
                                <div class="flex items-start space-x-2 sm:space-x-3">
                                    <input type="checkbox" name="selected_transactions[]"
                                        value="{{ $transaction->id }}"
                                        class="transaction-checkbox-mobile h-4 w-4 mt-1 text-pink-500 focus:ring-pink-400 border-gray-300 rounded cursor-pointer">
                                    
                                    <div class="flex-1 min-w-0">
                                        <div class="flex justify-between items-start mb-2 gap-2">
                                            <div class="min-w-0 flex-1">
                                                <h3 class="text-xs sm:text-sm font-semibold text-gray-900 truncate">{{ $transaction->invoice_number }}</h3>
                                                <p class="text-xs sm:text-sm text-gray-500 truncate">{{ $transaction->user->name ?? 'N/A' }}</p>
                                            </div>
                                            <span
                                                class="px-2 py-0.5 text-xs font-semibold rounded-full whitespace-nowrap
                                            {{ $transaction->payment_status == 'completed'
                                                ? 'bg-green-100 text-green-800'
                                                : ($transaction->payment_status == 'pending'
                                                    ? 'bg-yellow-100 text-yellow-800'
                                                    : 'bg-red-100 text-red-800') }}">
                                                {{ ucfirst($transaction->payment_status) }}
                                            </span>
                                        </div>
                                        
                                        <div class="mt-2 space-y-1 text-xs sm:text-sm">
                                            <div class="flex justify-between">
                                                <span class="text-gray-500">Total:</span>
                                                <span class="font-medium text-gray-900">Rp {{ number_format($transaction->total_amount, 0, ',', '.') }}</span>
                                            </div>
                                            
                                            <div class="flex justify-between">
                                                <span class="text-gray-500">Voucher:</span>
                                                <span class="text-gray-900">
                                                    @if($transaction->userVoucher?->type)
                                                        <span class="text-indigo-600">{{ ucfirst(str_replace('_', ' ', $transaction->userVoucher?->type)) }}</span>
                                                    @else
                                                        <span>-</span>
                                                    @endif
                                                </span>
                                            </div>
                                            
                                            <div class="flex justify-between">
                                                <span class="text-gray-500">Point:</span>
                                                <span class="text-gray-900 flex items-center gap-1">
                                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                                    </svg>
                                                    {{ $transaction->points_earned }}
                                                </span>
                                            </div>
                                            
                                            <div class="flex justify-between">
                                                <span class="text-gray-500">Tanggal:</span>
                                                <span class="text-gray-900">{{ $transaction->created_at->format('d M Y H:i') }}</span>
                                            </div>
                                        </div>
                                        
                                        <div class="mt-3 flex justify-end">
                                            <a href="{{ route('admin.transactions.show', $transaction->id) }}"
                                                class="inline-flex items-center px-3 py-1.5 text-xs sm:text-sm font-medium text-pink-500 bg-pink-50 rounded-lg hover:bg-pink-100 transition duration-150">
                                                <span>Lihat Detail</span>
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 sm:h-4 sm:w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                                                </svg>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @empty
                            <div class="py-8 sm:py-10 px-3 sm:px-4">
                                <div class="flex flex-col items-center justify-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 sm:h-10 sm:w-10 text-gray-400 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                    </svg>
                                    <span class="text-sm text-gray-500 text-center">Tidak ada data transaksi</span>
                                </div>
                            </div>
                        @endforelse
                    </div>
                </div>

                <!-- Action Bar -->
                <div class="px-3 sm:px-4 lg:px-5 py-3 sm:py-4 bg-gray-50 border-t border-gray-200">
                    <div class="flex flex-col gap-3 sm:gap-4">
                        <div class="text-xs sm:text-sm text-gray-600">
                            Menampilkan {{ $transactions->firstItem() ?? 0 }} sampai
                            {{ $transactions->lastItem() ?? 0 }} dari {{ $transactions->total() }} data
                        </div>
                        <button type="submit"
                            class="w-full inline-flex items-center justify-center px-3 sm:px-4 py-2 border border-transparent rounded-lg shadow-sm text-xs sm:text-sm font-medium text-white bg-[#FF8FA4] hover:bg-[#F542C8] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500 transition duration-150">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 sm:h-5 sm:w-5 mr-2" fill="none"
                                viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                            Export Excel
                        </button>
                    </div>
                </div>
            </form>

            <!-- Pagination -->
            <div class="px-3 sm:px-4 lg:px-5 py-4 bg-white border-t border-gray-200">
                {{ $transactions->appends(request()->query())->links() }}
            </div>
        </div>
    </div>
</div>
@endsection

@push('script')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Desktop view checkboxes
        const selectAllCheckbox = document.getElementById('select-all');
        const transactionCheckboxes = document.querySelectorAll('.transaction-checkbox');

        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', function() {
                transactionCheckboxes.forEach(checkbox => {
                    checkbox.checked = selectAllCheckbox.checked;
                });
            });

            // Update "select all" checkbox when individual checkboxes change
            transactionCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    const allChecked = Array.from(transactionCheckboxes).every(cb => cb.checked);
                    const someChecked = Array.from(transactionCheckboxes).some(cb => cb.checked);
                    
                    selectAllCheckbox.checked = allChecked;
                    selectAllCheckbox.indeterminate = someChecked && !allChecked;
                });
            });
        }

        // Mobile view checkboxes
        const selectAllMobileCheckbox = document.getElementById('select-all-mobile');
        const transactionMobileCheckboxes = document.querySelectorAll('.transaction-checkbox-mobile');

        if (selectAllMobileCheckbox) {
            selectAllMobileCheckbox.addEventListener('change', function() {
                transactionMobileCheckboxes.forEach(checkbox => {
                    checkbox.checked = selectAllMobileCheckbox.checked;
                });
            });

            // Update "select all" mobile checkbox when individual mobile checkboxes change
            transactionMobileCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    const allChecked = Array.from(transactionMobileCheckboxes).every(cb => cb.checked);
                    const someChecked = Array.from(transactionMobileCheckboxes).some(cb => cb.checked);
                    
                    selectAllMobileCheckbox.checked = allChecked;
                    selectAllMobileCheckbox.indeterminate = someChecked && !allChecked;
                });
            });
        }

        // Sync desktop and mobile checkboxes
        if (selectAllCheckbox && selectAllMobileCheckbox) {
            selectAllCheckbox.addEventListener('change', function() {
                selectAllMobileCheckbox.checked = selectAllCheckbox.checked;
                selectAllMobileCheckbox.indeterminate = selectAllCheckbox.indeterminate;
            });

            selectAllMobileCheckbox.addEventListener('change', function() {
                selectAllCheckbox.checked = selectAllMobileCheckbox.checked;
                selectAllCheckbox.indeterminate = selectAllMobileCheckbox.indeterminate;
            });
        }
    });
</script>
@endpush