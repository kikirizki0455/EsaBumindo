@extends('layouts.admin')

@section('title', 'Detail Transaksi | Fairy Nails')

@section('content')
    <div class="container mx-auto px-4 sm:px-8 py-8 max-w-screen-xl">
        <div class="flex items-center justify-between mb-8">
            <h1 class="text-lg font-bold text-[#FF8FA4]">
                <span class="bg-[#FF8FA4] text-xs text-white p-2 rounded-lg shadow-md">Detail Transaksi
                </span>

            </h1>
            <a href="{{ route('admin.transactions') }}"
                class="bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold py-2 px-4 rounded-lg transition duration-300 flex items-center text-xs">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd"
                        d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z"
                        clip-rule="evenodd" />
                </svg>
                Kembali
            </a>
        </div>

        <!-- Informasi Transaksi -->
        <div class="bg-white rounded-lg shadow-lg overflow-hidden mb-4 sm:mb-8 w-full max-w-4xl mx-auto">
            <div class="px-2 sm:px-4 md:px-6 py-3 sm:py-4 border-b bg-gradient-to-r from-[#FF8FA4] to-[#F542C8]">
                <h2 class="text-base sm:text-lg md:text-xl font-semibold text-white truncate">Informasi Transaksi</h2>
            </div>

            <div class="p-3 sm:p-4 md:p-6">
                @php
                    // Hitung total diskon dan subtotal
                    $totalPrice = 0;
                    $totalDiscount = 0;
                    $voucherDiscount = 0;
                    $totalSubtotal = 0;
                    $totalItems = 0;

                    // Hitung total harga dan jumlah item
                    foreach ($transaction->transactionDetails as $detail) {
                        $itemPrice = $detail->price * $detail->quantity;
                        $itemDiscount = 0;
                        
                        // Cek diskon per item
                        if ($detail->discount > 0) {
                            $itemDiscount = $itemPrice * ($detail->discount / 100);
                        }
                        
                        // Cek apakah ada diskon voucher untuk kategori produk ini
                        if ($transaction->voucher && $transaction->voucher->type === 'percentage_discount') {
                            if ($detail->product->category === $transaction->voucher->product_category) {
                                $itemDiscount = $itemPrice * ($transaction->voucher->value / 100);
                            }
                        }
                        
                        $itemSubtotal = $itemPrice - $itemDiscount;
                        
                        $totalPrice += $itemPrice;
                        $totalDiscount += $itemDiscount;
                        $totalSubtotal += $itemSubtotal;
                        $totalItems += $detail->quantity;
                    }

                    // Hitung diskon voucher global (jika ada dan berbeda dari diskon per kategori)
                    if ($transaction->voucher && $transaction->voucher->type === 'fixed_discount') {
                        $voucherDiscount = $transaction->voucher->value;
                        $totalSubtotal -= $voucherDiscount;
                    }
                    
                    // Pastikan total tidak negatif
                    $totalSubtotal = max(0, $totalSubtotal);
                @endphp

                <div class="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4 md:gap-6">
                    <div class="space-y-2 sm:space-y-3 md:space-y-4">
                        <div>
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">Invoice</h3>
                            <p
                                class="mt-0.5 sm:mt-1 text-sm sm:text-base md:text-lg font-semibold text-gray-900 break-words">
                                {{ $transaction->invoice_number }}</p>
                        </div>
                        <div>
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">Nama Pelanggan</h3>
                            <p
                                class="mt-0.5 sm:mt-1 text-sm sm:text-base md:text-lg font-semibold text-gray-900 break-words">
                                {{ $transaction->user->name ?? 'N/A' }}</p>
                        </div>
                        <div>
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">Email Pelanggan</h3>
                            <p class="mt-0.5 sm:mt-1 text-sm sm:text-base md:text-lg font-semibold text-gray-900 break-all">
                                {{ $transaction->user->email ?? 'N/A' }}</p>
                        </div>
                        <div>
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">No. Telepon</h3>
                            <p class="mt-0.5 sm:mt-1 text-sm sm:text-base md:text-lg font-semibold text-gray-900">
                                {{ $transaction->user->phone ?? 'N/A' }}</p>
                        </div>
                    </div>

                    <div class="space-y-2 sm:space-y-3 md:space-y-4 mt-3 md:mt-0">
                        <div>
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">Tanggal Transaksi</h3>
                            <p class="mt-0.5 sm:mt-1 text-sm sm:text-base md:text-lg font-semibold text-gray-900">
                                {{ $transaction->created_at->format('d M Y H:i') }}</p>
                        </div>
                        <div>
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">Status Pembayaran</h3>
                            <p class="mt-0.5 sm:mt-1">
                                <span
                                    class="px-1.5 sm:px-2 py-0.5 sm:py-1 inline-flex text-xs sm:text-sm leading-5 font-semibold rounded-full 
                                {{ $transaction->payment_status == 'completed'
                                    ? 'bg-green-100 text-green-800'
                                    : ($transaction->payment_status == 'pending'
                                        ? 'bg-yellow-100 text-yellow-800'
                                        : 'bg-red-100 text-red-800') }}">
                                    {{ ucfirst($transaction->payment_status) }}
                                </span>
                            </p>
                        </div>
                        <div>
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">Poin yang Didapat</h3>
                            <p class="mt-0.5 sm:mt-1 text-sm sm:text-base md:text-lg font-semibold text-gray-900">
                                {{ $transaction->points_earned }} poin</p>
                        </div>
                        <div>
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">XP yang Didapat</h3>
                            <p class="mt-0.5 sm:mt-1 text-sm sm:text-base md:text-lg font-semibold text-gray-900">
                                {{ $transaction->xp_earned }} xp</p>
                        </div>
                    </div>
                </div>

                @if ($transaction->voucher_id)
                    <div class="mt-3 sm:mt-4 md:mt-6 pt-3 sm:pt-4 md:pt-6 border-t border-gray-200">
                        <h3 class="text-xs sm:text-sm md:text-base font-semibold text-gray-700">Informasi Voucher</h3>
                        <div class="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3 md:gap-4">
                            <div>
                                <p class="text-xs sm:text-sm text-gray-500">Tipe Voucher</p>
                                <p class="font-medium text-xs sm:text-sm md:text-base">
                                    {{ ucfirst(str_replace('_', ' ', $transaction->userVoucher?->voucher?->type ?? 'tidak ada')) }}
                                </p>
                            </div>
                            @if ($transaction->userVoucher->type === 'percentage_discount')
                                <div>
                                    <p class="text-xs sm:text-sm text-gray-500">Nilai Diskon</p>
                                    <p class="font-medium text-xs sm:text-sm md:text-base">
                                        {{ number_format($transaction->voucher->value, 0) }}%</p>
                                </div>
                                <div>
                                    <p class="text-xs sm:text-sm text-gray-500">Kategori Produk</p>
                                    <p class="font-medium text-xs sm:text-sm md:text-base">
                                        {{ $transaction->voucher->product_category ?? 'Semua Kategori' }}</p>
                                </div>
                            @elseif(optional($transaction->userVoucher?->voucher)->type === 'free_service')
                                <div>
                                    <p class="text-xs sm:text-sm text-gray-500">Layanan Gratis</p>
                                    <p class="font-medium text-xs sm:text-sm md:text-base">{{ $voucherName }}</p>
                                </div>
                            @endif
                        </div>
                    </div>
                @endif
            </div>
        </div>

        <!-- Detail Item Transaksi -->
        <div class="bg-white rounded-lg shadow-lg overflow-hidden mb-4 sm:mb-6">
            {{-- header --}}
            <div class="px-3 sm:px-4 md:px-6 py-3 sm:py-4 border-b bg-gradient-to-r from-[#FF8FA4] to-[#F542C8]">
                <h2 class="text-base sm:text-lg md:text-xl font-semibold text-white">Detail Item</h2>
            </div>

            <!-- Table for larger screens -->
            <div class="hidden sm:block overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col"
                                class="px-2 sm:px-4 md:px-6 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                No
                            </th>
                            <th scope="col"
                                class="px-2 sm:px-4 md:px-6 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Produk/Layanan
                            </th>
                            <th scope="col"
                                class="px-2 sm:px-4 md:px-6 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Harga
                            </th>
                            <th scope="col"
                                class="px-2 sm:px-4 md:px-6 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Jumlah
                            </th>
                            <th scope="col"
                                class="px-2 sm:px-4 md:px-6 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Voucher
                            </th>
                            <th scope="col"
                                class="px-2 sm:px-4 md:px-6 py-2 sm:py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Subtotal
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @foreach ($transaction->transactionDetails as $index => $detail)
                            @php
                                $price = $detail->price * $detail->quantity;
                                $discount = $detail->discount;

                                // Apply voucher discount jika sesuai
                                if (
                                    $transaction->voucher &&
                                    $transaction->voucher->type === 'percentage_discount' &&
                                    $detail->product->category === $transaction->voucher->product_category
                                ) {
                                    $discount = $transaction->voucher->value;
                                }

                                $itemDiscount = $price * ($discount / 100);
                                $subtotal = $price - $itemDiscount;
                            @endphp

                            <tr>
                                <td
                                    class="px-2 sm:px-4 md:px-6 py-2 sm:py-4 whitespace-nowrap text-xs sm:text-sm text-gray-500">
                                    {{ $index + 1 }}
                                </td>
                                <td class="px-2 sm:px-4 md:px-6 py-2 sm:py-4 whitespace-nowrap">
                                    <div class="text-xs sm:text-sm font-medium text-gray-900">
                                        {{ $detail->product->name ?? 'Produk tidak tersedia' }}
                                    </div>
                                    <div class="text-xs sm:text-sm text-gray-500">
                                        {{ $detail->product->category ?? 'Tidak ada kategori' }}
                                    </div>
                                </td>
                                <td
                                    class="px-2 sm:px-4 md:px-6 py-2 sm:py-4 whitespace-nowrap text-xs sm:text-sm text-gray-500">
                                    Rp {{ number_format($detail->price, 0, ',', '.') }}
                                </td>
                                <td
                                    class="px-2 sm:px-4 md:px-6 py-2 sm:py-4 whitespace-nowrap text-xs sm:text-sm text-gray-500">
                                    {{ $detail->quantity }}
                                </td>
                                <td
                                    class="px-2 sm:px-4 md:px-6 py-2 sm:py-4 whitespace-nowrap text-xs sm:text-sm text-gray-500">
                                    {{ $transaction->userVoucher?->voucher?->name ?? '0' }}
                                </td>
                                <td
                                    class="px-2 sm:px-4 md:px-6 py-2 sm:py-4 whitespace-nowrap text-xs sm:text-sm text-gray-500">
                                    Rp {{ number_format($subtotal, 0, ',', '.') }}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!-- Card view for mobile screens -->
            <div class="sm:hidden">
                @foreach ($transaction->transactionDetails as $index => $detail)
                    @php
                        $price = $detail->price * $detail->quantity;
                        $discount = $detail->discount;

                        // Apply voucher discount jika sesuai
                        if (
                            $transaction->voucher &&
                            $transaction->voucher->type === 'percentage_discount' &&
                            $detail->product->category === $transaction->voucher->product_category
                        ) {
                            $discount = $transaction->voucher->value;
                        }

                        $itemDiscount = $price * ($discount / 100);
                        $subtotal = $price - $itemDiscount;
                    @endphp

                    <div class="border-b border-gray-200 p-3">
                        <div class="flex justify-between items-start mb-1">
                            <p class="text-xs font-medium text-gray-900">No</p>
                            <p class="text-xs text-gray-500">{{ $index + 1 }}</p>
                        </div>
                        <div class="flex justify-between items-start mb-1">
                            <div>
                                <p class="text-xs font-medium text-gray-900">Produk/Layanan</p>
                            </div>
                            <div class="text-right">
                                <p class="text-xs font-medium">{{ $detail->product->name ?? 'Produk tidak tersedia' }}</p>
                                <p class="text-xs text-gray-500">{{ $detail->product->category ?? 'Tidak ada kategori' }}
                                </p>
                            </div>
                        </div>
                        <div class="flex justify-between items-start mb-1">
                            <p class="text-xs font-medium text-gray-900">Harga</p>
                            <p class="text-xs text-gray-500">Rp {{ number_format($detail->price, 0, ',', '.') }}</p>
                        </div>
                        <div class="flex justify-between items-start mb-1">
                            <p class="text-xs font-medium text-gray-900">Jumlah</p>
                            <p class="text-xs text-gray-500">{{ $detail->quantity }}</p>
                        </div>
                        <div class="flex justify-between items-start mb-1">
                            <p class="text-xs font-medium text-gray-900">Voucher</p>
                            <p class="text-xs text-gray-500">{{ $transaction->userVoucher?->voucher?->name ?? '0' }}</p>
                        </div>
                        <div class="flex justify-between items-start">
                            <p class="text-xs font-medium text-gray-900">Subtotal</p>
                            <p class="text-xs text-gray-500 font-semibold">Rp {{ number_format($subtotal, 0, ',', '.') }}
                            </p>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="p-3 sm:p-4 md:p-6 bg-gray-50">
                <div class="flex flex-col w-full">
                    <!-- Detail Breakdown -->
                    <div class="w-full space-y-2 sm:space-y-3">
                        <!-- Header Ringkasan -->
                        <h3 class="font-bold text-sm sm:text-base text-gray-900 mb-3">Ringkasan Pembayaran</h3>
                        
                        <!-- Detail Item -->
                        <div class="bg-white rounded-lg p-2 sm:p-3 space-y-2 border border-gray-200 mb-3">
                            <div class="flex justify-between text-xs sm:text-sm font-medium">
                                <span class="text-gray-600">Detail Item:</span>
                            </div>
                            @php $itemCount = 1; @endphp
                            @foreach ($transaction->transactionDetails as $detail)
                                @php
                                    $itemPrice = $detail->price * $detail->quantity;
                                @endphp
                                <div class="flex justify-between text-xs sm:text-sm text-gray-600 pl-2 border-l-2 border-gray-300 gap-2">
                                    <span class="truncate">{{ $itemCount }}. {{ $detail->product->name ?? 'Produk' }} ({{ $detail->quantity }}x)</span>
                                    <span class="font-medium text-gray-900 whitespace-nowrap">Rp {{ number_format($itemPrice, 0, ',', '.') }}</span>
                                </div>
                                @php $itemCount++; @endphp
                            @endforeach
                        </div>

                        <!-- Subtotal Semua Item -->
                        <div class="flex justify-between text-xs sm:text-sm font-semibold text-gray-900 bg-white rounded-lg p-2 sm:p-3 border border-gray-300 gap-2">
                            <span>Total Item:</span>
                            <span class="whitespace-nowrap">Rp {{ number_format($subtotal, 0, ',', '.') }}</span>
                        </div>

                        <!-- Diskon Level -->
                        @if ($transaction->user && $xpDiscount > 0)
                            @php
                                $levelDiscountAmount = ($subtotal * $xpDiscount) / 100;
                            @endphp
                            <div class="flex justify-between text-xs sm:text-sm text-blue-600 font-medium bg-blue-50 rounded-lg p-2 sm:p-3 border border-blue-200 gap-2">
                                <span>Diskon Level ({{ $userLevel }})</span>
                                <span class="whitespace-nowrap">- Rp {{ number_format($levelDiscountAmount, 0, ',', '.') }}</span>
                            </div>
                        @endif

                        <!-- Diskon Voucher -->
                        @if ($transaction->voucher_id)
                            <div class="bg-white rounded-lg p-2 sm:p-3 border border-green-200 mb-3">
                                <div class="flex justify-between text-xs sm:text-sm font-medium mb-2 pb-2 border-b border-green-100">
                                    <span class="text-gray-700">Info Voucher:</span>
                                </div>
                                <div class="space-y-1">
                                    <div class="flex justify-between text-xs sm:text-sm text-gray-600 gap-2">
                                        <span>Nama:</span>
                                        <span class="font-medium text-gray-900 text-right">{{ $voucherName }}</span>
                                    </div>
                                    <div class="flex justify-between text-xs sm:text-sm text-gray-600 gap-2">
                                        <span>Tipe:</span>
                                        <span class="font-medium text-gray-900 text-right">
                                            @if ($voucherType === 'percentage_discount')
                                                <span class="inline-block bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">Diskon %</span>
                                            @elseif ($voucherType === 'free_service')
                                                <span class="inline-block bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Gratis</span>
                                            @else
                                                <span class="inline-block bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs">-</span>
                                            @endif
                                        </span>
                                    </div>
                                    @if ($voucherType === 'percentage_discount')
                                        <div class="flex justify-between text-xs sm:text-sm text-gray-600 gap-2">
                                            <span>Nilai:</span>
                                            <span class="font-medium text-gray-900">{{ $voucherValue }}%</span>
                                        </div>
                                    @endif
                                    <div class="flex justify-between text-xs sm:text-sm text-green-600 font-medium gap-2 pt-1 border-t border-green-100">
                                        <span>Diskon Voucher</span>
                                        <span class="whitespace-nowrap">- Rp {{ number_format($voucherDiscountAmount, 0, ',', '.') }}</span>
                                    </div>
                                </div>
                            </div>
                        @endif

                        <!-- Total Diskon -->
                        @if (($transaction->user && $xpDiscount > 0) || $transaction->voucher_id)
                            @php
                                $totalDiscountAmount = ($transaction->user && $xpDiscount > 0 ? ($subtotal * $xpDiscount) / 100 : 0) + ($transaction->voucher_id ? $voucherDiscountAmount : 0);
                            @endphp
                            <div class="flex justify-between text-xs sm:text-sm font-semibold text-red-600 bg-red-50 rounded-lg p-2 sm:p-3 border border-red-300 gap-2">
                                <span>Total Diskon:</span>
                                <span class="whitespace-nowrap">- Rp {{ number_format($totalDiscountAmount, 0, ',', '.') }}</span>
                            </div>
                        @endif

                        <!-- Total Akhir -->
                        <div class="flex justify-between text-sm sm:text-base lg:text-lg font-bold text-white bg-gradient-to-r from-[#FF8FA4] to-[#F542C8] rounded-lg p-3 sm:p-4 border-2 border-[#FF8FA4] gap-2">
                            <span>Total Bayar:</span>
                            <span class="whitespace-nowrap">Rp {{ number_format($totalAmount, 0, ',', '.') }}</span>
                        </div>
                    </div>
                </div>

                <!-- Form untuk input total -->
                <form action="{{ route('admin.transactions.update-total', $transaction->id) }}" method="POST"
                    class="w-full mt-4">
                    @csrf
                    @method('PUT')
                    <div class="pt-3 border-t border-gray-200">
                        <div class="flex flex-col sm:flex-row sm:justify-end mt-3 items-start sm:items-center gap-2">
                            <span class="text-xs sm:text-sm font-medium text-gray-600 whitespace-nowrap">Edit Total (jika perlu):</span>
                            <input type="text" name="total_amount"
                                value="{{ number_format($totalAmount, 0, ',', '.') }}"
                                class="text-sm sm:text-base font-bold text-[#FF8FA4] bg-transparent border border-gray-300 rounded px-2 sm:px-3 py-2 text-right focus:outline-none focus:ring-2 focus:ring-[#FF8FA4] w-full sm:w-auto min-w-fit"
                                required>
                        </div>
                        <div class="flex flex-col sm:flex-row justify-end mt-3 gap-2">
                            @if ($transaction->payment_status === 'pending' || $transaction->payment_status === 'process')
                                <button type="button" onclick="resetTotal()"
                                    class="w-full sm:w-auto px-3 py-2 sm:px-4 text-xs sm:text-sm bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition">
                                    Reset
                                </button>
                                <button type="submit"
                                    class="w-full sm:w-auto px-3 py-2 sm:px-4 text-xs sm:text-sm bg-[#FF8FA4] text-white rounded hover:bg-[#e07b92] transition">
                                    Simpan
                                </button>
                            @elseif ($transaction->payment_status === 'completed')
                                <p class="text-xs sm:text-sm text-green-600 font-medium">✓ Pembayaran Selesai</p>
                            @endif
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tombol Aksi -->
        <div class="px-3 sm:px-4 md:px-6 py-3 sm:py-4 bg-gray-50 border-t border-gray-200">
            <div class="flex flex-col sm:flex-row sm:justify-between gap-2">
                @if ($transaction->payment_status === 'pending' || $transaction->payment_status === 'process')
                    <form action="{{ route('admin.transactions.update-status', $transaction->id) }}" method="POST"
                        class="w-full sm:w-auto"
                        onsubmit="return confirm('Apakah Anda yakin ingin menyelesaikan transaksi ini?')">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="status" value="completed">
                        <button type="submit"
                            class="w-full sm:w-auto bg-green-500 hover:bg-green-600 text-white px-3 py-2 sm:px-4 text-xs sm:text-sm rounded-lg transition duration-300">
                            Selesaikan Transaksi
                        </button>
                    </form>
                    <form action="{{ route('admin.transactions.update-status', $transaction->id) }}" method="POST"
                        class="w-full sm:w-auto mt-2 sm:mt-0"
                        onsubmit="return confirm('Apakah Anda yakin ingin membatalkan transaksi ini?')">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="status" value="cancelled">
                        <button type="submit"
                            class="w-full sm:w-auto bg-red-500 hover:bg-red-600 text-white px-3 py-2 sm:px-4 text-xs sm:text-sm rounded-lg transition duration-300">
                            Batalkan Transaksi
                        </button>
                    </form>
                @elseif ($transaction->payment_status === 'completed')
                @endif
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        function resetTotal() {
            const calculatedTotal = {{ $totalSubtotal }};
            document.querySelector('input[name="total_amount"]').value =
                new Intl.NumberFormat('id-ID').format(calculatedTotal);
        }
    </script>
@endpush