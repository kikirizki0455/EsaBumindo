@extends('layouts.admin')

@section('title', 'Transaksi | Fairy Nails')

@section('content')
<div class="container mx-auto px-3 sm:px-4 lg:px-8 py-4 sm:py-6">
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        <!-- Bagian Kiri: Pilih Pelanggan dan Voucher -->
        <div class="lg:col-span-1 order-2 lg:order-1">
            <div class="bg-white rounded-lg shadow p-3 sm:p-4 lg:p-6 lg:sticky lg:top-4">
                <h2 class="text-lg sm:text-xl font-bold mb-3 sm:mb-4 text-pink-600">Detail Transaksi</h2>
                
                <!-- Member Selection Toggle -->
                <div class="mb-3 sm:mb-4 pb-3 sm:pb-4 border-b border-gray-200">
                    <label class="flex items-center cursor-pointer">
                        <input type="checkbox" id="enableMemberToggle" class="w-4 h-4 text-pink-500 rounded focus:ring-pink-500 cursor-pointer">
                        <span class="ml-2 text-sm sm:text-base text-gray-700 font-medium">Transaksi dengan Member</span>
                    </label>
                    <p class="text-xs sm:text-sm text-gray-500 mt-1">Centang untuk memilih member, biarkan kosong untuk transaksi umum</p>
                </div>

                <!-- Member Selection (Initially Hidden) -->
                <div id="memberSelectionSection" class="mb-3 sm:mb-4 hidden">
                    <label class="block mb-2 font-medium text-xs sm:text-sm text-gray-700">Pilih Member</label>
                    <div class="relative">
                        <input type="text" id="userSearchInput" placeholder="Cari member (ID atau nama)" 
                            class="w-full border border-gray-300 rounded-lg px-2 sm:px-3 py-2 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-pink-500">
                        <input type="hidden" name="user_id" id="selectedUserId">
                        
                        <!-- Dropdown untuk hasil pencarian -->
                        <div id="searchResults" class="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg hidden max-h-48 sm:max-h-60 overflow-y-auto">
                            <!-- Hasil pencarian akan ditampilkan di sini -->
                        </div>
                        
                        <!-- Informasi member terpilih -->
                        <div id="selectedUserInfo" class="mt-2 p-2 sm:p-3 border border-gray-200 rounded-lg hidden">
                            <div class="flex justify-between items-start gap-2">
                                <div class="min-w-0 flex-1">
                                    <p id="selectedUserName" class="font-medium text-xs sm:text-sm truncate"></p>
                                    <p id="selectedUserIdText" class="text-xs text-gray-500 truncate"></p>
                                </div>
                                <div id="userLevelInfo" class="text-xs sm:text-sm mt-1 hidden whitespace-nowrap">
                                    <span id="userLevelBadge" class="inline-block px-2 py-1 rounded text-xs font-semibold text-white"></span>
                                </div>
                            </div>
                            <button type="button" id="clearMemberBtn" class="mt-2 text-xs sm:text-sm text-red-500 hover:text-red-700">Hapus Pilihan</button>
                        </div>
                    </div>
                </div>

                <!-- Voucher Selection (Only visible when member is selected) -->
                <div id="voucherSection" class="mb-3 sm:mb-4 hidden">
                    <label class="block mb-2 font-medium text-xs sm:text-sm text-gray-700">Pilih Voucher (Opsional)</label>
                    <select name="voucher_id" id="voucherSelect" class="w-full border border-gray-300 rounded-lg px-2 sm:px-3 py-2 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-pink-500">
                        <option value="">-- Pilih Voucher --</option>
                    </select>
                    <p id="noVoucherMessage" class="text-gray-500 text-xs sm:text-sm mt-1">Pilih member terlebih dahulu</p>
                </div>

                <!-- Cart Summary -->
                <div class="mt-4 sm:mt-6 pt-3 sm:pt-4 border-t border-gray-200">
                    <h3 class="font-bold text-xs sm:text-sm text-gray-700 mb-2 sm:mb-3">Ringkasan Belanja</h3>
                    <div class="space-y-1 sm:space-y-2">
                        <div class="flex justify-between text-xs sm:text-sm text-gray-600 gap-2">
                            <span>Subtotal:</span>
                            <span id="subtotalAmount" class="font-medium whitespace-nowrap">Rp 0</span>
                        </div>
                        <!-- Diskon Level -->
                        <div class="flex justify-between text-xs sm:text-sm text-blue-600 gap-2" id="levelDiscountContainer">
                            <span>Diskon Level <span id="userLevelText"></span>:</span>
                            <span id="levelDiscountAmount" class="font-medium whitespace-nowrap">-Rp 0</span>
                        </div>
                        <div class="flex justify-between text-xs sm:text-sm text-pink-600 gap-2">
                            <span>Diskon Voucher:</span>
                            <span id="discountAmount" class="font-medium whitespace-nowrap">-Rp 0</span>
                        </div>
                        <div class="flex justify-between font-bold text-sm sm:text-base mt-2 pt-2 sm:pt-3 border-t border-gray-200 gap-2">
                            <span>Total Bayar:</span>
                            <span id="finalTotal" class="text-pink-600 whitespace-nowrap">Rp 0</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bagian Tengah & Kanan: Produk & Keranjang -->
        <div class="lg:col-span-2 order-1 lg:order-2">
            <!-- Product Selection -->
            <div class="bg-white rounded-lg shadow p-3 sm:p-4 lg:p-6 mb-4 sm:mb-6">
                <h2 class="text-lg sm:text-xl font-bold mb-3 sm:mb-4 text-pink-600">Pilih Produk</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                    @foreach($products as $product)
                    <div class="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                        <div class="p-3 sm:p-4">
                            <h3 class="font-semibold text-xs sm:text-sm text-gray-800 line-clamp-2">{{ $product->name }}</h3>
                            <p class="text-pink-600 font-medium mt-1 text-xs sm:text-sm">Rp {{ number_format($product->price, 0, ',', '.') }}</p>
                            <form action="{{ route('admin.transactions.add-to-cart') }}" method="POST" class="mt-3 flex items-end gap-2">
                                @csrf
                                <input type="hidden" name="product_id" value="{{ $product->id }}">
                                <div class="flex-1">
                                    <label class="text-xs text-gray-600 block mb-1">Jumlah</label>
                                    <input type="number" name="quantity" value="1" min="1" class="w-full border border-gray-300 rounded px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-pink-500">
                                </div>
                                <button type="submit" class="bg-pink-500 text-white px-2 py-1 sm:px-3 rounded hover:bg-pink-600 transition-colors flex items-center gap-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 sm:h-4 sm:w-4" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd" />
                                    </svg>
                                    <span class="hidden sm:inline">Tambah</span>
                                </button>
                            </form>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>

            <!-- Cart Items -->
            <div class="bg-white rounded-lg shadow p-3 sm:p-4 lg:p-6">
                <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-3 sm:mb-4 gap-2">
                    <h2 class="text-lg sm:text-xl font-bold text-pink-600">Keranjang Belanja</h2>
                    @if(count(session('admin_cart', [])) > 0)
                    <form action="{{ route('admin.cart.clear') }}" method="POST" class="w-full sm:w-auto">
                        @csrf
                        <button type="submit" 
                                class="w-full sm:w-auto text-red-500 hover:text-red-700 transition-colors text-xs sm:text-sm flex items-center gap-1 justify-center sm:justify-start"
                                onclick="return confirm('Yakin ingin mengosongkan keranjang?')">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 sm:h-4 sm:w-4" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
                            </svg>
                            Kosongkan
                        </button>
                    </form>
                    @endif
                </div>
                <form action="{{ route('admin.transactions.store') }}" method="POST" id="checkoutForm">
                    @csrf
                    <!-- Hidden inputs for checkout data -->
                    <input type="hidden" name="user_id" id="checkoutUserId" value="">
                    <input type="hidden" name="voucher_id" id="checkoutVoucherId" value="">
                    <input type="hidden" name="subtotal" id="checkoutSubtotal" value="0">
                    <input type="hidden" name="discount" id="checkoutDiscount" value="0">
                    <input type="hidden" name="level_discount" id="checkoutLevelDiscount" value="0">
                    <input type="hidden" name="final_total" id="checkoutFinalTotal" value="0">
                    <input type="hidden" name="user_level" id="checkoutUserLevel" value="">
                
                    <div id="cartItemsList" class="divide-y divide-gray-200">
                        @php $total = 0 @endphp
                        @if(count(session('admin_cart', [])) > 0)
                            @foreach(session('admin_cart', []) as $cartId => $item)
                                <div class="py-3 sm:py-4 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2 sm:gap-4 cart-item" 
                                     data-price="{{ $item['price'] }}" 
                                     data-quantity="{{ $item['quantity'] }}">
                                    <div class="flex-1 min-w-0">
                                        <h4 class="font-medium text-xs sm:text-sm text-gray-800 truncate">{{ $item['name'] }}</h4>
                                        <p class="text-xs sm:text-sm text-gray-500">Rp {{ number_format($item['price'], 0, ',', '.') }} x {{ $item['quantity'] }}</p>
                                    </div>
                                    <span class="font-medium text-pink-600 item-total text-xs sm:text-sm whitespace-nowrap">Rp {{ number_format($item['price'] * $item['quantity'], 0, ',', '.') }}</span>
                                </div>
                                @php $total += $item['price'] * $item['quantity'] @endphp
                            @endforeach
                        @else
                            <div class="py-6 sm:py-8 text-center">
                                <div class="text-gray-400 mb-3">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 sm:h-12 sm:w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                                    </svg>
                                </div>
                                <p class="text-xs sm:text-sm text-gray-500">Keranjang belanja masih kosong</p>
                            </div>
                        @endif
                    </div>
                
                    <div class="mt-4 sm:mt-6">
                        <!-- Button untuk desktop -->
                        <button type="submit" id="checkoutButton"
                                class="w-full bg-pink-500 text-white py-2 sm:py-3 rounded-lg font-medium text-sm sm:text-base hover:bg-pink-600 transition-colors lg:flex lg:items-center lg:justify-center gap-2 hidden-mobile">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 sm:h-5 sm:w-5" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3z" />
                            </svg>
                            Proses Transaksi
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@if(session('error'))
    <div class="fixed bottom-4 right-4 bg-red-100 border-l-4 border-red-500 text-red-700 p-3 sm:p-4 rounded shadow-lg z-50 max-w-xs" role="alert">
        <p class="font-medium text-xs sm:text-sm">{{ session('error') }}</p>
    </div>
@endif

@if(session('success'))
    <div class="fixed bottom-4 right-4 bg-green-100 border-l-4 border-green-500 text-green-700 p-3 sm:p-4 rounded shadow-lg z-50 max-w-xs" role="alert">
        <p class="font-medium text-xs sm:text-sm">{{ session('success') }}</p>
    </div>
@endif

<!-- Fixed checkout bar on mobile - Disederhanakan hanya 1 button -->
<div id="mobileCheckoutBar" class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-3 sm:p-4 shadow-lg hidden z-40">
    <div class="flex justify-between items-center gap-3">
        <div>
            <p class="text-xs text-gray-600">Total:</p>
            <p id="mobileTotal" class="font-bold text-pink-600 text-sm sm:text-lg whitespace-nowrap">Rp 0</p>
        </div>
        <button type="button" id="mobileProceedButton" 
                class="flex-1 bg-pink-500 text-white px-3 py-2 sm:px-6 sm:py-3 rounded-lg font-medium text-xs sm:text-sm hover:bg-pink-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
            Proses
        </button>
    </div>
</div>
<style>
    @media (max-width: 1023px) {
        .hidden-mobile {
            display: none !important;
        }
        
        /* Add padding to body to account for fixed mobile checkout bar */
        body {
            padding-bottom: 80px;
        }
    }
    
    /* Warna badge untuk level user */
    .badge-bronze {
        background: linear-gradient(to bottom right, #cd7f32, #8b4513);
        border: 4px solid #8b4513;
        box-shadow: 0 4px 15px rgba(139, 69, 19, 0.3);
        color: white;
    }

    .badge-silver {
        background: linear-gradient(to bottom right, #c0c0c0, #808080);
        border: 4px solid #d3d3d3;
        box-shadow: 0 4px 15px rgba(211, 211, 211, 0.3);
        color: white;
    }

    .badge-gold {
        background: linear-gradient(to bottom right, #ffd700, #daa520);
        border: 4px solid #ffd700;
        box-shadow: 0 4px 15px rgba(255, 215, 0, 0.3);
        color: #333;
    }

    .badge-platinum {
        background: linear-gradient(to bottom right, #e5e4e2, #a2a3a3, #b9b9b9);
        border: 4px solid #8fd8ff;
        box-shadow: 0 4px 15px rgba(143, 216, 255, 0.3);
        color: #333;
        animation: platinum-glow 2s infinite alternate;
    }

    /* Animasi glow khusus platinum */
    @keyframes platinum-glow {
        0% {
            box-shadow: 0 0 10px rgba(143, 216, 255, 0.3);
        }
        100% {
            box-shadow: 0 0 20px rgba(143, 216, 255, 0.6);
        }
    }
</style>

@endsection
@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const userSelect = document.getElementById('userSelect');
    const voucherSelect = document.getElementById('voucherSelect');
    const discountAmount = document.getElementById('discountAmount');
    const levelDiscountAmount = document.getElementById('levelDiscountAmount');
    const levelDiscountContainer = document.getElementById('levelDiscountContainer');
    const userLevelText = document.getElementById('userLevelText');
    const userLevelInfo = document.getElementById('userLevelInfo');
    const userLevelBadge = document.getElementById('userLevelBadge');
    const finalTotal = document.getElementById('finalTotal');
    const subtotalAmount = document.getElementById('subtotalAmount');
    const cartItemsList = document.getElementById('cartItemsList');
    const noVoucherMessage = document.getElementById('noVoucherMessage');
    const checkoutButton = document.getElementById('checkoutButton');
    const mobileCheckoutBar = document.getElementById('mobileCheckoutBar');
    const mobileProceedButton = document.getElementById('mobileProceedButton');
    const mobileTotal = document.getElementById('mobileTotal');
    const checkoutForm = document.getElementById('checkoutForm');
    
    // Variabel untuk user selection baru
    const userSearchInput = document.getElementById('userSearchInput');
    const searchResults = document.getElementById('searchResults');
    const selectedUserInfo = document.getElementById('selectedUserInfo');
    const selectedUserName = document.getElementById('selectedUserName');
    const selectedUserIdDisplay = document.getElementById('selectedUserIdText');
    const selectedUserIdInput = document.getElementById('selectedUserId');

    // Hidden inputs for checkout
    const checkoutUserId = document.getElementById('checkoutUserId');
    const checkoutVoucherId = document.getElementById('checkoutVoucherId');
    const checkoutSubtotal = document.getElementById('checkoutSubtotal');
    const checkoutDiscount = document.getElementById('checkoutDiscount');
    const checkoutLevelDiscount = document.getElementById('checkoutLevelDiscount');
    const checkoutFinalTotal = document.getElementById('checkoutFinalTotal');
    const checkoutUserLevel = document.getElementById('checkoutUserLevel');
    
    // Global variabel untuk menyimpan detail diskon level
    let currentLevelDiscount = {
        level: '',
        discount: null
    };
    
    // Data users dari PHP yang akan kita konversi ke array JavaScript
    const usersData = [
        @foreach(App\Models\User::where('role', 'user')->get() as $user)
        {
            id: "{{ $user->id }}",
            formattedId: "{{ 'FN' . str_pad($user->id, 4, '0', STR_PAD_LEFT) }}",
            name: "{{ $user->name }}",
            level: "{{ $user->level }}",
            discount: {!! json_encode($user->getDiscountLevel()) !!}
        },
        @endforeach
    ];
    
    // Variabel untuk menyimpan user yang terpilih
    let selectedUser = null;
    
    // Show mobile checkout bar on small screens
    function toggleMobileCheckoutBar() {
        if (window.innerWidth < 1024) { // lg breakpoint in Tailwind
            mobileCheckoutBar.classList.remove('hidden');
        } else {
            mobileCheckoutBar.classList.add('hidden');
        }
    }
    
    // Fungsi untuk memfilter users berdasarkan input
    function filterUsers(searchTerm) {
        searchTerm = searchTerm.toLowerCase();
        return usersData.filter(user => {
            return user.formattedId.toLowerCase().includes(searchTerm) || 
                   user.name.toLowerCase().includes(searchTerm);
        });
    }
    
    // Fungsi untuk menampilkan hasil pencarian
    function displaySearchResults(results) {
        searchResults.innerHTML = '';
        
        if (results.length === 0) {
            const noResult = document.createElement('div');
            noResult.className = 'p-3 text-gray-500 text-center';
            noResult.textContent = 'Tidak ada hasil yang sesuai';
            searchResults.appendChild(noResult);
        } else {
            results.forEach(user => {
                const resultItem = document.createElement('div');
                resultItem.className = 'p-3 hover:bg-gray-100 cursor-pointer';
                resultItem.innerHTML = `
                    <div class="flex justify-between items-center">
                        <div>
                            <p class="font-medium">${user.name}</p>
                            <p class="text-sm text-gray-500">${user.formattedId}</p>
                        </div>
                        <div class="badge-${user.level.toLowerCase()} inline-block px-2 py-1 rounded text-xs font-semibold text-white">
                            ${user.level.toUpperCase()}
                        </div>
                    </div>
                `;
                
                // Event click untuk memilih user
                resultItem.addEventListener('click', function() {
                    selectUser(user);
                });
                
                searchResults.appendChild(resultItem);
            });
        }
        
        searchResults.classList.remove('hidden');
    }
    
    // Fungsi untuk memilih user
    function selectUser(user) {
        selectedUser = user;
        
        // Update input search dengan nama user
        userSearchInput.value = `${user.formattedId} - ${user.name}`;
        
        // Update hidden input dengan ID user
        selectedUserIdInput.value = user.id;
        
        // Update tampilan info user
        selectedUserName.textContent = user.name;
        selectedUserIdDisplay.textContent = user.formattedId;
        
        // Update badge level
        userLevelBadge.textContent = user.level.toUpperCase();
        userLevelBadge.className = `inline-block px-2 py-1 rounded text-xs font-semibold text-white badge-${user.level.toLowerCase()}`;
        
        // Tampilkan info user
        selectedUserInfo.classList.remove('hidden');
        
        // Sembunyikan hasil pencarian
        searchResults.classList.add('hidden');
        
        // Update UI level info
        userLevelInfo.classList.remove('hidden');
        updateUserLevelBadge(user.level);
        
        // Update hidden input untuk checkout
        checkoutUserId.value = user.id;
        
        // Update informasi level user
        updateUserLevelFromObject(user);
        
        // Load vouchers untuk user ini
        loadUserVouchers(user.id);
        
        // Update checkout button state
        updateCheckoutButtonState();
        
        // Calculate total
        calculateTotal();
    }
    
    // Fungsi untuk update badge level
    function updateUserLevelBadge(level) {
        // Reset classes
        userLevelBadge.className = 'inline-block px-2 py-1 rounded text-xs font-semibold text-white';
        
        // Add appropriate class based on level
        switch(level.toLowerCase()) {
            case 'bronze':
                userLevelBadge.classList.add('badge-bronze');
                break;
            case 'silver':
                userLevelBadge.classList.add('badge-silver');
                break;
            case 'gold':
                userLevelBadge.classList.add('badge-gold');
                break;
            case 'platinum':
                userLevelBadge.classList.add('badge-platinum');
                break;
            default:
                userLevelBadge.classList.add('bg-gray-500');
        }
        
        userLevelBadge.textContent = `Level: ${level.toUpperCase()}`;
    }
    
    // Event untuk input pencarian
    // userSearchInput.addEventListener('input', function() {
    //     const searchTerm = this.value;
        
    //     if (searchTerm.length >= 1) {
    //         const results = filterUsers(searchTerm);
    //         displaySearchResults(results);
    //     } else {
    //         searchResults.classList.add('hidden');
    //     }
    // });
    
    // Hindari enter submit form
    // userSearchInput.addEventListener('keydown', function(e) {
    //     if (e.key === 'Enter') {
    //         e.preventDefault();
            
    //         // Jika ada hasil pencarian yang ditampilkan, pilih yang pertama
    //         const firstResult = searchResults.querySelector('.cursor-pointer');
    //         if (firstResult) {
    //             firstResult.click();
    //         }
    //     }
    // });
    
    // Sembunyikan hasil pencarian saat klik di luar
    document.addEventListener('click', function(e) {
        if (!userSearchInput.contains(e.target) && !searchResults.contains(e.target)) {
            searchResults.classList.add('hidden');
            
            // Jika input kosong dan user sudah terpilih, kembalikan nilai input
            if (userSearchInput.value === '' && selectedUser) {
                userSearchInput.value = `${selectedUser.formattedId} - ${selectedUser.name}`;
            }
        }
    });

    // Fungsi untuk mengatur status tombol checkout (menggunakan kode asli)
    function updateCheckoutButtonState() {
        const cartItems = cartItemsList.querySelectorAll('.cart-item');
        const hasItems = cartItems.length > 0;
        const selectedUser = selectedUserIdInput ? selectedUserIdInput.value : null;
        
        // Log status untuk debugging
        console.log('Cart items:', cartItems.length);
        console.log('Selected user:', selectedUser);
        console.log('Has items:', hasItems);
        
        // Memeriksa kondisi untuk mengaktifkan tombol
        // const shouldEnable = hasItems && selectedUser;
        const shouldEnable = hasItems ;
        
        if (!shouldEnable) {
            if (checkoutButton) {
                checkoutButton.setAttribute('disabled', 'disabled');
                checkoutButton.classList.add('opacity-50', 'cursor-not-allowed');
            }
            
            if (mobileProceedButton) {
                mobileProceedButton.setAttribute('disabled', 'disabled');
                mobileProceedButton.classList.add('opacity-50', 'cursor-not-allowed');
            }
        } else {
            if (checkoutButton) {
                checkoutButton.removeAttribute('disabled');
                checkoutButton.classList.remove('opacity-50', 'cursor-not-allowed');
            }
            
            if (mobileProceedButton) {
                mobileProceedButton.removeAttribute('disabled');
                mobileProceedButton.classList.remove('opacity-50', 'cursor-not-allowed');
            }
        }
        
        // Log status setelah update
        console.log('Checkout button disabled:', checkoutButton ? checkoutButton.disabled : 'not found');
    }

    function formatRupiah(number) {
        return new Intl.NumberFormat('id-ID').format(number);
    }

    function calculateSubtotal() {
        let subtotal = 0;
        const items = cartItemsList.querySelectorAll('.cart-item');
        
        items.forEach(item => {
            const price = parseFloat(item.dataset.price);
            const quantity = parseInt(item.dataset.quantity);
            subtotal += price * quantity;
        });
        
        return subtotal;
    }
    
    function calculateTotal() {
        const subtotal = calculateSubtotal();
        let voucherDiscount = 0;
        let levelDiscount = 0;
        
        // Hitung diskon dari voucher
        // const selectedOption = voucherSelect.options[voucherSelect.selectedIndex];
        // if (selectedOption && selectedOption.dataset.type) {
        //     const voucherType = selectedOption.dataset.type;
        //     const voucherValue = parseFloat(selectedOption.dataset.value) || 0;
        //     const minTransaction = parseFloat(selectedOption.dataset.min) || 0;
            
        //     if (subtotal >= minTransaction) {
        //         if (voucherType === 'percentage_discount') {
        //             voucherDiscount = (subtotal * voucherValue) / 100;
        //         } else if (voucherType === 'free_service') {
        //             voucherDiscount = subtotal;
        //         }
        //     }
        // }
        
        // Hitung diskon level jika ada
        if (currentLevelDiscount && currentLevelDiscount.discount !== null) {
            levelDiscount = (subtotal * currentLevelDiscount.discount) / 100;
        }
        
        // Total akhir: subtotal - diskon voucher - diskon level
        const finalAmount = Math.max(0, subtotal - voucherDiscount - levelDiscount);
        
        // Update tampilan
        subtotalAmount.textContent = `Rp ${formatRupiah(subtotal)}`;
        discountAmount.textContent = `-Rp ${formatRupiah(voucherDiscount)}`;
        levelDiscountAmount.textContent = `-Rp ${formatRupiah(levelDiscount)}`;
        finalTotal.textContent = `Rp ${formatRupiah(finalAmount)}`;
        
        if (mobileTotal) {
            mobileTotal.textContent = `Rp ${formatRupiah(finalAmount)}`;
        }
        
        // Update hidden inputs
        checkoutSubtotal.value = subtotal;
        checkoutDiscount.value = voucherDiscount;
        checkoutLevelDiscount.value = levelDiscount;
        checkoutFinalTotal.value = finalAmount;
        
        // Tampilkan atau sembunyikan bagian diskon level berdasarkan apakah user memiliki diskon level
        if (currentLevelDiscount.discount !== null) {
            levelDiscountContainer.classList.remove('hidden');
            userLevelText.textContent = currentLevelDiscount.level;
        } else {
            levelDiscountContainer.classList.add('hidden');
        }
    }
    
    // Fungsi untuk memuat voucher user (menggunakan kode asli)
    async function loadUserVouchers(userId) {
        if (!userId) {
            voucherSelect.innerHTML = '<option value="">-- Pilih Voucher --</option>';
            noVoucherMessage.textContent = 'Pilih pelanggan terlebih dahulu';
            return;
        }

        try {
            const response = await fetch(`{{ url('admin/transactions/get-user-vouchers') }}/${userId}`);
            const vouchers = await response.json();
            
            voucherSelect.innerHTML = '<option value="">-- Pilih Voucher --</option>';
            
            if (vouchers && vouchers.length > 0) {
                vouchers.forEach(voucher => {
                    const option = document.createElement('option');
                    option.value = voucher.id;
                    option.dataset.type = voucher.type;
                    option.dataset.value = voucher.value;
                    option.dataset.min = voucher.minimum_transaction;
                    
                    let voucherText = `${voucher.name}`;
                    if (voucher.type === 'percentage_discount') {
                        voucherText += ` - ${voucher.value}%`;
                    } else if (voucher.type === 'free_service') {
                        voucherText += ' - Gratis';
                    }
                    if (voucher.minimum_transaction) {
                        voucherText += ` (Min. Rp ${formatRupiah(voucher.minimum_transaction)})`;
                    }
                    
                    option.textContent = voucherText;
                    voucherSelect.appendChild(option);
                });
                noVoucherMessage.textContent = '';
            } else {
                noVoucherMessage.textContent = 'Pelanggan tidak memiliki voucher';
            }
        } catch (error) {
            console.error('Error loading vouchers:', error);
            noVoucherMessage.textContent = 'Gagal memuat voucher';
        }
    }

    // Fungsi untuk mengatur informasi level user dari object user
    function updateUserLevelFromObject(user) {
        if (!user || !user.discount) {
            currentLevelDiscount = { level: '', discount: null };
            return;
        }
        
        try {
            currentLevelDiscount = {
                level: user.discount.level,
                discount: user.discount.discount
            };
            
            // Update hidden input for user level
            checkoutUserLevel.value = user.discount.level;
            
            // Tampilkan badge level jika ada diskon
            if (user.discount.discount !== null) {
                userLevelInfo.classList.remove('hidden');
                userLevelBadge.textContent = `${user.discount.level} (${user.discount.discount}%)`;
                userLevelBadge.className = `inline-block px-2 py-1 rounded text-xs font-semibold text-white badge-${user.discount.level.toLowerCase()}`;
            } else {
                userLevelInfo.classList.add('hidden');
            }
            
        } catch (error) {
            console.error('Error updating user level from object:', error);
            userLevelInfo.classList.add('hidden');
            currentLevelDiscount = { level: '', discount: null };
        }
    }

    // Event untuk Voucher Selection
    if (voucherSelect) {
        voucherSelect.addEventListener('change', function() {
            // Update hidden input for voucher_id
            checkoutVoucherId.value = this.value;
            
            // Calculate total with selected voucher
            calculateTotal();
        });
    }
    
    // Event untuk mobile proceed button - Submit form
    if (mobileProceedButton) {
        mobileProceedButton.addEventListener('click', function() {
            if (!this.disabled) {
                checkoutForm.submit();
            }
        });
    }
    
    // Pastikan checkoutButton berfungsi (meskipun ini seharusnya otomatis karena type="submit")
    if (checkoutButton) {
        checkoutButton.addEventListener('click', function(e) {
            e.preventDefault(); // Tambahkan ini untuk jaga-jaga
            if (!this.disabled) {
                console.log('Checkout button clicked');
                checkoutForm.submit();
            }
        });
    }

    // Initial setup
    calculateTotal();
    updateCheckoutButtonState();
    toggleMobileCheckoutBar();
    window.addEventListener('resize', toggleMobileCheckoutBar);
    
    // Tambahkan CSS untuk badges
    const style = document.createElement('style');
    style.textContent = `
        .badge-bronze {
            background-color: #cd7f32;
        }
        .badge-silver {
            background-color: #c0c0c0;
        }
        .badge-gold {
            background-color: #ffd700;
            color: #333;
        }
        .badge-platinum {
            background-color: #e5e4e2;
            color: #333;
        }
    `;
    document.head.appendChild(style);
    
    // Tambahkan console log untuk debugging
    console.log('Script loaded successfully');
    console.log('Checkout button:', checkoutButton);
    console.log('Mobile proceed button:', mobileProceedButton);
    console.log('Checkout form:', checkoutForm);

    // Elemen untuk member toggle
    const enableMemberToggle = document.getElementById('enableMemberToggle');
    const memberSelectionSection = document.getElementById('memberSelectionSection');
    const voucherSection = document.getElementById('voucherSection');
    const clearMemberBtn = document.getElementById('clearMemberBtn');
    
    // Fungsi untuk toggle member selection
    function toggleMemberSelection() {
        if (enableMemberToggle.checked) {
            memberSelectionSection.classList.remove('hidden');
            userSearchInput.focus();
        } else {
            memberSelectionSection.classList.add('hidden');
            voucherSection.classList.add('hidden');
            // Clear member selection
            clearMemberSelection();
        }
    }
    
    // Fungsi untuk clear member selection
    function clearMemberSelection() {
        selectedUser = null;
        selectedUserIdInput.value = '';
        checkoutUserId.value = '';
        userSearchInput.value = '';
        selectedUserInfo.classList.add('hidden');
        searchResults.classList.add('hidden');
        voucherSelect.innerHTML = '<option value="">-- Pilih Voucher --</option>';
        checkoutVoucherId.value = '';
        currentLevelDiscount = { level: '', discount: null };
        calculateTotal();
        updateCheckoutButtonState();
    }
    
    // Event listener untuk toggle member
    if (enableMemberToggle) {
        enableMemberToggle.addEventListener('change', toggleMemberSelection);
    }
    
    // Event listener untuk clear member button
    if (clearMemberBtn) {
        clearMemberBtn.addEventListener('click', function(e) {
            e.preventDefault();
            enableMemberToggle.checked = false;
            toggleMemberSelection();
        });
    }
    
    // Update selectUser untuk menampilkan voucher section
    const originalSelectUser = selectUser;
    selectUser = function(user) {
        originalSelectUser(user);
        voucherSection.classList.remove('hidden');
    };
    
    // Update input pencarian untuk menampilkan dropdown
    if (userSearchInput) {
        userSearchInput.addEventListener('input', function() {
            const searchTerm = this.value;
            
            if (searchTerm.length >= 1) {
                const results = filterUsers(searchTerm);
                displaySearchResults(results);
            } else {
                searchResults.classList.add('hidden');
            }
        });
        
        // Hindari enter submit form
        userSearchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                
                // Jika ada hasil pencarian yang ditampilkan, pilih yang pertama
                const firstResult = searchResults.querySelector('.cursor-pointer');
                if (firstResult) {
                    firstResult.click();
                }
            }
        });
    }
});
</script>
@endpush